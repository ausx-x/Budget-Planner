import { useState, useMemo, useCallback, useEffect } from 'react';
import { Transaction, RecurringExpense, SavingsGoal, TransactionType, MonthlySummary, YearlySummary, ExpenseCategory, Currency, CategoryBudget, Toast, RecurringIncome } from '../types';
import { MONTH_NAMES, EXPENSE_CATEGORIES } from '../constants';

const usePersistentState = <T,>(key: string, initialValue: T): [T, React.Dispatch<React.SetStateAction<T>>] => {
    const [state, setState] = useState<T>(() => {
        try {
            const item = window.localStorage.getItem(key);
            return item ? JSON.parse(item) : initialValue;
        } catch (error) {
            console.error(error);
            return initialValue;
        }
    });

    useEffect(() => {
        try {
            window.localStorage.setItem(key, JSON.stringify(state));
        } catch (error) {
            console.error(error);
        }
    }, [key, state]);

    return [state, setState];
};


const getInitialTransactions = (): Transaction[] => {
    const currentYear = new Date().getFullYear();
    return [
        { id: '2', type: TransactionType.INCOME, description: 'Freelance Project', amount: 50000, date: `${currentYear}-01-15T10:00:00Z` },
        { id: '3', type: TransactionType.EXPENSE, description: 'Groceries', amount: 25000, date: `${currentYear}-01-05T10:00:00Z`, category: ExpenseCategory.FOOD },
        { id: '4', type: TransactionType.EXPENSE, description: 'Gasoline', amount: 8000, date: `${currentYear}-01-10T10:00:00Z`, category: ExpenseCategory.TRANSPORT },
        { id: '6', type: TransactionType.EXPENSE, description: 'Dinner Out', amount: 12000, date: `${currentYear}-02-12T10:00:00Z`, category: ExpenseCategory.ENTERTAINMENT },
    ];
};

const getInitialRecurringIncomes = (): RecurringIncome[] => {
    return [
        { id: 'ri1', description: 'Monthly Salary', amount: 350000 },
    ];
};

const getInitialRecurringExpenses = (): RecurringExpense[] => {
    return [
        { id: 'r1', description: 'Rent', amount: 120000, category: ExpenseCategory.HOUSING },
        { id: 'r2', description: 'Internet', amount: 1000, category: ExpenseCategory.UTILITIES },
        { id: 'r3', description: 'Gym Membership', amount: 2500, category: ExpenseCategory.HEALTH },
    ];
};

const getInitialSavingsGoals = (): SavingsGoal[] => {
    return [
        { id: 's1', destination: 'Nifty 50 Index Fund SIP', amount: 50000 },
        { id: 's2', destination: 'Emergency Fund FD', amount: 20000 },
        { id: 's3', destination: 'Savings Account', amount: 30000 },
    ];
};

const getInitialCategoryBudgets = (): CategoryBudget[] => {
    return [
        { category: ExpenseCategory.FOOD, amount: 40000 },
        { category: ExpenseCategory.ENTERTAINMENT, amount: 15000 },
        { category: ExpenseCategory.SHOPPING, amount: 20000 },
    ];
};

export const useBudget = () => {
  const [transactions, setTransactions] = usePersistentState<Transaction[]>('transactions', getInitialTransactions());
  const [recurringIncomes, setRecurringIncomes] = usePersistentState<RecurringIncome[]>('recurringIncomes', getInitialRecurringIncomes());
  const [recurringExpenses, setRecurringExpenses] = usePersistentState<RecurringExpense[]>('recurringExpenses', getInitialRecurringExpenses());
  const [savingsGoals, setSavingsGoals] = usePersistentState<SavingsGoal[]>('savingsGoals', getInitialSavingsGoals());
  const [categoryBudgets, setCategoryBudgets] = usePersistentState<CategoryBudget[]>('categoryBudgets', getInitialCategoryBudgets());
  const [selectedYear, setSelectedYear] = usePersistentState<number>('selectedYear', new Date().getFullYear());
  const [currency, setCurrency] = usePersistentState<Currency>('currency', Currency.INR);
  const [toasts, setToasts] = useState<Toast[]>([]);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [dateRange, setDateRange] = useState({ start: '', end: '' });

  const dismissToast = useCallback((id: string) => {
    setToasts(currentToasts => currentToasts.filter(t => t.id !== id));
  }, []);

  const addToast = useCallback((message: string, type: 'success' | 'error' = 'success') => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
        dismissToast(id);
    }, 3000);
  }, [dismissToast]);

  const formatCurrency = useCallback((amount: number) => {
    return new Intl.NumberFormat(currency === Currency.INR ? 'en-IN' : 'en-US', {
        style: 'currency',
        currency: currency,
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
    }).format(amount);
  }, [currency]);

  const addTransaction = useCallback((transaction: Omit<Transaction, 'id'>) => {
    setTransactions(prev => [...prev, { ...transaction, id: Date.now().toString() }]);
  }, [setTransactions]);

  const updateTransaction = useCallback((updatedTransaction: Transaction) => {
    setTransactions(prev => prev.map(t => t.id === updatedTransaction.id ? updatedTransaction : t));
  }, [setTransactions]);

  const deleteTransaction = useCallback((id: string) => {
    setTransactions(prev => prev.filter(t => t.id !== id));
  }, [setTransactions]);
  
  const addRecurringIncome = useCallback((income: Omit<RecurringIncome, 'id'>) => {
    setRecurringIncomes(prev => [...prev, { ...income, id: Date.now().toString() }]);
  }, [setRecurringIncomes]);

  const updateRecurringIncome = useCallback((updatedIncome: RecurringIncome) => {
    setRecurringIncomes(prev => prev.map(i => i.id === updatedIncome.id ? updatedIncome : i));
  }, [setRecurringIncomes]);

  const deleteRecurringIncome = useCallback((id: string) => {
    setRecurringIncomes(prev => prev.filter(i => i.id !== id));
  }, [setRecurringIncomes]);

  const addRecurringExpense = useCallback((expense: Omit<RecurringExpense, 'id'>) => {
    setRecurringExpenses(prev => [...prev, { ...expense, id: Date.now().toString() }]);
  }, [setRecurringExpenses]);

  const updateRecurringExpense = useCallback((updatedExpense: RecurringExpense) => {
    setRecurringExpenses(prev => prev.map(r => r.id === updatedExpense.id ? updatedExpense : r));
  }, [setRecurringExpenses]);

  const deleteRecurringExpense = useCallback((id: string) => {
    setRecurringExpenses(prev => prev.filter(r => r.id !== id));
  }, [setRecurringExpenses]);

  const addSavingsGoal = useCallback((goal: Omit<SavingsGoal, 'id'>) => {
    setSavingsGoals(prev => [...prev, { ...goal, id: Date.now().toString() }]);
  }, [setSavingsGoals]);
  
  const updateSavingsGoal = useCallback((updatedGoal: SavingsGoal) => {
    setSavingsGoals(prev => prev.map(g => g.id === updatedGoal.id ? updatedGoal : g));
  }, [setSavingsGoals]);

  const deleteSavingsGoal = useCallback((id: string) => {
    setSavingsGoals(prev => prev.filter(s => s.id !== id));
  }, [setSavingsGoals]);

  const setCategoryBudget = useCallback((budget: CategoryBudget) => {
    setCategoryBudgets(prev => {
        const existing = prev.find(b => b.category === budget.category);
        if (existing) {
            return prev.map(b => b.category === budget.category ? budget : b);
        }
        return [...prev, budget];
    });
  }, [setCategoryBudgets]);

  const deleteCategoryBudget = useCallback((category: ExpenseCategory) => {
    setCategoryBudgets(prev => prev.filter(b => b.category !== category));
  }, [setCategoryBudgets]);


  const filteredByYearTransactions = useMemo(() => {
    return transactions.filter(t => new Date(t.date).getFullYear() === selectedYear);
  }, [transactions, selectedYear]);
  
  const monthlySummaries = useMemo<MonthlySummary[]>(() => {
    const totalRecurringExpenses = recurringExpenses.reduce((sum, r) => sum + r.amount, 0);
    const totalRecurringIncomes = recurringIncomes.reduce((sum, i) => sum + i.amount, 0);

    return MONTH_NAMES.map((month, index) => {
      const monthTransactions = filteredByYearTransactions.filter(t => new Date(t.date).getMonth() === index);
      
      const transactionalIncome = monthTransactions
        .filter(t => t.type === TransactionType.INCOME)
        .reduce((sum, t) => sum + t.amount, 0);
      
      const income = transactionalIncome + totalRecurringIncomes;
        
      const oneTimeExpenses = monthTransactions
        .filter(t => t.type === TransactionType.EXPENSE)
        .reduce((sum, t) => sum + t.amount, 0);
        
      const expenses = oneTimeExpenses + totalRecurringExpenses;
      const balance = income - expenses;

      return { month, monthIndex: index, income, expenses, balance };
    });
  }, [filteredByYearTransactions, recurringExpenses, recurringIncomes]);

  const yearlySummary = useMemo<YearlySummary>(() => {
    const totalMonthlySavings = savingsGoals.reduce((sum, goal) => sum + goal.amount, 0);

    return monthlySummaries.reduce((acc, month) => {
      acc.totalIncome += month.income;
      acc.totalExpenses += month.expenses;
      acc.totalBalance += month.balance;
      return acc;
    }, { totalIncome: 0, totalExpenses: 0, totalBalance: 0, totalSavings: totalMonthlySavings * 12 });
  }, [monthlySummaries, savingsGoals]);

  const applyFilters = useCallback((transactions: Transaction[]) => {
    return transactions.filter(t => {
      const transactionDate = new Date(t.date);
      const startDate = dateRange.start ? new Date(dateRange.start) : null;
      const endDate = dateRange.end ? new Date(dateRange.end) : null;
      if (startDate) startDate.setHours(0,0,0,0);
      if (endDate) endDate.setHours(23,59,59,999);

      const matchesSearch = t.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = t.type === TransactionType.INCOME || categoryFilter === 'all' || t.category === categoryFilter;
      const matchesDate = (!startDate || transactionDate >= startDate) && (!endDate || transactionDate <= endDate);

      return matchesSearch && matchesCategory && matchesDate;
    });
  }, [searchQuery, categoryFilter, dateRange]);

  const incomeTransactions = useMemo(() => {
    const income = filteredByYearTransactions
      .filter(t => t.type === TransactionType.INCOME);
    return applyFilters(income).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [filteredByYearTransactions, applyFilters]);

  const expenseTransactions = useMemo(() => {
    const expenses = filteredByYearTransactions
      .filter(t => t.type === TransactionType.EXPENSE);
    return applyFilters(expenses).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [filteredByYearTransactions, applyFilters]);

  const expenseCategoriesData = useMemo(() => {
    const categoryMap = new Map<string, number>();

    filteredByYearTransactions.filter(t => t.type === TransactionType.EXPENSE).forEach(t => {
        if (t.category) {
            categoryMap.set(t.category, (categoryMap.get(t.category) || 0) + t.amount);
        }
    });
    
    recurringExpenses.forEach(r => {
        categoryMap.set(r.category, (categoryMap.get(r.category) || 0) + (r.amount * 12));
    });

    return EXPENSE_CATEGORIES.map(category => {
        const spent = categoryMap.get(category) || 0;
        const budget = categoryBudgets.find(b => b.category === category)?.amount;
        return { name: category, value: spent, budget: budget };
    }).filter(data => data.value > 0 || data.budget !== undefined);

  }, [filteredByYearTransactions, recurringExpenses, categoryBudgets]);

  return {
    transactions,
    recurringIncomes,
    recurringExpenses,
    savingsGoals,
    selectedYear,
    currency,
    setCurrency,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    addRecurringIncome,
    updateRecurringIncome,
    deleteRecurringIncome,
    addRecurringExpense,
    updateRecurringExpense,
    deleteRecurringExpense,
    addSavingsGoal,
    updateSavingsGoal,
    deleteSavingsGoal,
    setSelectedYear,
    monthlySummaries,
    yearlySummary,
    incomeTransactions,
    expenseTransactions,
    expenseCategoriesData,
    formatCurrency,
    categoryBudgets,
    setCategoryBudget,
    deleteCategoryBudget,
    toasts,
    addToast,
    dismissToast,
    searchQuery,
    setSearchQuery,
    categoryFilter,
    setCategoryFilter,
    dateRange,
    setDateRange,
  };
};