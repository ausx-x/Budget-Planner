import React, { useState, useEffect } from 'react';
import { RecurringIncome } from '../types';
import { Card, CardHeader } from './Card';
import { TrashIcon, PlusCircleIcon, EditIcon, XIcon } from './icons';

interface RecurringIncomeManagerProps {
  recurringIncomes: RecurringIncome[];
  addRecurringIncome: (income: Omit<RecurringIncome, 'id'>) => void;
  updateRecurringIncome: (income: RecurringIncome) => void;
  deleteRecurringIncome: (id: string) => void;
  formatCurrency: (amount: number) => string;
  addToast: (message: string) => void;
}

const EditRecurringIncomeModal: React.FC<{
    income: RecurringIncome | null;
    onClose: () => void;
    onSave: (income: RecurringIncome) => void;
}> = ({ income, onClose, onSave }) => {
    const [description, setDescription] = useState('');
    const [amount, setAmount] = useState('');

    useEffect(() => {
        if (income) {
            setDescription(income.description);
            setAmount(income.amount.toString());
        }
    }, [income]);
    
    if (!income) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            ...income,
            description,
            amount: parseFloat(amount),
        });
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold">Edit Fixed Income</h3>
                    <button onClick={onClose}><XIcon className="h-6 w-6 text-slate-500" /></button>
                </div>
                <form onSubmit={handleSubmit} className="space-y-4">
                     <div>
                        <label htmlFor="edit-rec-inc-description" className="block text-sm font-medium text-slate-700">Description</label>
                        <input type="text" id="edit-rec-inc-description" value={description} onChange={(e) => setDescription(e.target.value)} className="mt-1 block w-full rounded-md bg-white text-slate-900 border-gray-300 shadow-sm" required />
                    </div>
                    <div>
                        <label htmlFor="edit-rec-inc-amount" className="block text-sm font-medium text-slate-700">Amount</label>
                        <input type="number" id="edit-rec-inc-amount" value={amount} onChange={(e) => setAmount(e.target.value)} className="mt-1 block w-full rounded-md bg-white text-slate-900 border-gray-300 shadow-sm" required min="0.01" step="0.01" />
                    </div>
                    <div className="flex justify-end space-x-2 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-sm bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300">Cancel</button>
                        <button type="submit" className="px-4 py-2 text-sm bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    );
};


export const RecurringIncomeManager: React.FC<RecurringIncomeManagerProps> = ({
  recurringIncomes,
  addRecurringIncome,
  updateRecurringIncome,
  deleteRecurringIncome,
  formatCurrency,
  addToast,
}) => {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [editingIncome, setEditingIncome] = useState<RecurringIncome | null>(null);

  const resetForm = () => {
    setDescription('');
    setAmount('');
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description || !amount) return;
    
    addRecurringIncome({ description, amount: parseFloat(amount) });
    addToast('Fixed income added!');
    
    resetForm();
  };

  const handleSave = (income: RecurringIncome) => {
    updateRecurringIncome(income);
    addToast('Fixed income updated!');
    setEditingIncome(null);
  };

  const handleDelete = (id: string) => {
    deleteRecurringIncome(id);
    addToast('Fixed income deleted!');
  };

  return (
    <Card>
      <CardHeader>Fixed Monthly Income</CardHeader>
      <div className="mb-4 space-y-2 max-h-48 overflow-y-auto pr-2">
        {recurringIncomes.map(income => (
          <div key={income.id} className="flex justify-between items-center bg-slate-100 p-2 rounded-md">
            <p className="font-medium text-slate-800">{income.description}</p>
            <div className="flex items-center space-x-2">
                <span className="font-semibold text-green-600">{formatCurrency(income.amount)}</span>
                <button onClick={() => setEditingIncome(income)} className="text-slate-500 hover:text-indigo-600">
                    <EditIcon className="h-4 w-4" />
                </button>
                <button onClick={() => handleDelete(income.id)} className="text-slate-500 hover:text-red-700">
                    <TrashIcon className="h-4 w-4" />
                </button>
            </div>
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="space-y-3 pt-4 border-t">
        <h4 className="text-md font-medium text-slate-600">Add New Fixed Income</h4>
        <input
          type="text"
          value={description}
          onChange={e => setDescription(e.target.value)}
          placeholder="Description (e.g., Salary)"
          className="block w-full text-sm rounded-md bg-white text-slate-900 border-gray-300 shadow-sm"
          required
        />
        <input
          type="number"
          value={amount}
          onChange={e => setAmount(e.target.value)}
          placeholder="Amount"
          className="block w-full text-sm rounded-md bg-white text-slate-900 border-gray-300 shadow-sm"
          required
          min="0.01"
          step="0.01"
        />
        <div className="flex space-x-2">
            <button type="submit" className="w-full flex items-center justify-center bg-green-600 text-white py-2 px-4 text-sm rounded-md hover:bg-green-700">
                <PlusCircleIcon className="h-5 w-5 mr-2" /> Add Income
            </button>
        </div>
      </form>
      <EditRecurringIncomeModal
        income={editingIncome}
        onClose={() => setEditingIncome(null)}
        onSave={handleSave}
      />
    </Card>
  );
};