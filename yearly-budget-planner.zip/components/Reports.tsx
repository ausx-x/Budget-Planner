import React from 'react';
import { ResponsiveContainer, ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Brush } from 'recharts';
import { MonthlySummary } from '../types';
import { Card, CardHeader } from './Card';

interface ReportsProps {
  monthlySummaries: MonthlySummary[];
  expenseCategoriesData: { name: string; value: number; budget?: number }[];
  formatCurrency: (amount: number) => string;
}

const BudgetProgressBar: React.FC<{
    name: string;
    spent: number;
    budget: number;
    formatCurrency: (amount: number) => string;
}> = ({ name, spent, budget, formatCurrency }) => {
    const percentage = budget > 0 ? Math.min((spent / budget) * 100, 100) : 0;
    const isOverBudget = spent > budget;
    
    let color = 'bg-green-500';
    if (percentage > 90 || isOverBudget) {
        color = 'bg-red-500';
    } else if (percentage > 75) {
        color = 'bg-yellow-500';
    }

    return (
        <div>
            <div className="flex justify-between items-center mb-1 text-sm">
                <span className="font-medium text-slate-700">{name}</span>
                <span className={`font-semibold ${isOverBudget ? 'text-red-600' : 'text-slate-600'}`}>
                    {formatCurrency(spent)} / {formatCurrency(budget)}
                </span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-2.5">
                <div className={`${color} h-2.5 rounded-full`} style={{ width: `${percentage}%` }}></div>
            </div>
        </div>
    );
};

export const Reports: React.FC<ReportsProps> = ({ monthlySummaries, expenseCategoriesData, formatCurrency }) => {
    const budgetedExpenses = expenseCategoriesData.filter(d => d.budget !== undefined);
    const unbudgetedExpenses = expenseCategoriesData.filter(d => d.budget === undefined);

    const CustomTooltip = ({ active, payload, label }: any) => {
        if (active && payload && payload.length) {
            return (
            <div className="bg-white p-2 border border-slate-200 rounded shadow-sm text-sm">
                <p className="label font-bold text-slate-800">{`${label}`}</p>
                <p style={{ color: payload[0].color }}>{`Income: ${formatCurrency(payload[0].value)}`}</p>
                <p style={{ color: payload[1].color }}>{`Expenses: ${formatCurrency(payload[1].value)}`}</p>
                <p style={{ color: payload[2].stroke }}>{`Balance: ${formatCurrency(payload[2].value)}`}</p>
            </div>
            );
        }
        return null;
    };


  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        <div className="lg:col-span-3">
            <Card>
                <CardHeader>Monthly Financial Flow</CardHeader>
                <div style={{ width: '100%', height: 300 }}>
                    <ResponsiveContainer>
                        <ComposedChart 
                            data={monthlySummaries} 
                            margin={{ top: 5, right: 20, left: 10, bottom: 5 }}
                        >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                            dataKey="month" 
                            tick={{ fontSize: 10 }} 
                            tickFormatter={(value: string) => value.slice(0, 3)}
                            interval={0}
                        />
                        <YAxis 
                            tick={{ fontSize: 10 }} 
                            tickFormatter={(tick) => formatCurrency(tick).replace(/\.\d+/, '')}
                            width={90}
                        />
                        <Tooltip content={<CustomTooltip />}/>
                        <Legend wrapperStyle={{fontSize: "12px"}}/>
                        <Bar dataKey="income" fill="#16a34a" name="Income" maxBarSize={40}/>
                        <Bar dataKey="expenses" fill="#dc2626" name="Expenses" maxBarSize={40}/>
                        <Line type="monotone" dataKey="balance" stroke="#4f46e5" strokeWidth={2} name="Balance" dot={false} />
                        <Brush dataKey="month" height={25} stroke="#4f46e5" travellerWidth={15} />
                        </ComposedChart>
                    </ResponsiveContainer>
                </div>
            </Card>
        </div>
        <div className="lg:col-span-2">
            <Card>
                <CardHeader>Expenses by Category</CardHeader>
                <div className="space-y-4 max-h-[350px] overflow-y-auto pr-2">
                    {budgetedExpenses.length > 0 ? (
                      budgetedExpenses.map(data => (
                            <BudgetProgressBar 
                                key={data.name}
                                name={data.name}
                                spent={data.value}
                                budget={data.budget!}
                                formatCurrency={formatCurrency}
                            />
                        ))
                    ) : (
                        <div className="flex items-center justify-center h-full text-slate-500 py-10">
                            No budgeted expenses to display.
                        </div>
                    )}

                    {unbudgetedExpenses.length > 0 && (
                        <div className="pt-4 mt-4 border-t">
                            <h4 className="font-semibold text-slate-600 mb-2 text-sm">Unbudgeted Expenses</h4>
                             {unbudgetedExpenses.map(data => (
                                <div key={data.name} className="flex justify-between items-center text-sm">
                                    <span className="text-slate-700">{data.name}</span>
                                    <span className="font-medium text-slate-800">{formatCurrency(data.value)}</span>
                                </div>
                             ))}
                        </div>
                    )}
                </div>
            </Card>
        </div>
    </div>
  );
};