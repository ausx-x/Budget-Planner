import React from 'react';
import { YearlySummary } from '../types';
import { Card } from './Card';
import { ArrowUpIcon, ArrowDownIcon } from './icons';
import { PiggyBankIcon } from './icons';


interface YearlySummaryCardProps {
  summary: YearlySummary;
  year: number;
  formatCurrency: (amount: number) => string;
}

export const YearlySummaryCard: React.FC<YearlySummaryCardProps> = ({ summary, year, formatCurrency }) => {
  const isPositive = summary.totalBalance >= 0;
  const netBalance = summary.totalBalance - summary.totalSavings;
  const isNetPositive = netBalance >= 0;

  return (
    <Card>
        <h3 className="text-lg font-semibold text-slate-700 mb-2">Summary for {year}</h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4 max-w-xl mx-auto">
            <div className="flex items-center space-x-3 text-green-600 p-3 bg-green-50 rounded-lg">
                <ArrowUpIcon className="h-6 w-6 flex-shrink-0" />
                <div>
                    <p className="text-sm text-slate-500">Total Income</p>
                    <p className="font-bold text-lg">{formatCurrency(summary.totalIncome)}</p>
                </div>
            </div>
             <div className="flex items-center space-x-3 text-red-600 p-3 bg-red-50 rounded-lg">
                <ArrowDownIcon className="h-6 w-6 flex-shrink-0" />
                <div>
                    <p className="text-sm text-slate-500">Total Expenses</p>
                    <p className="font-bold text-lg">{formatCurrency(summary.totalExpenses)}</p>
                </div>
            </div>
            <div className="flex items-center space-x-3 text-indigo-600 p-3 bg-indigo-50 rounded-lg">
                <PiggyBankIcon className="h-6 w-6 flex-shrink-0" />
                <div>
                    <p className="text-sm text-slate-500">Allocated Savings</p>
                    <p className="font-bold text-lg">{formatCurrency(summary.totalSavings)}</p>
                </div>
            </div>
             <div className="flex items-center space-x-3 p-3 bg-slate-100 rounded-lg">
                <div className="w-6 h-6 flex-shrink-0" />
                <div>
                  <p className="text-sm text-slate-500">Gross Balance</p>
                  <p className={`font-bold text-lg ${isPositive ? 'text-slate-800' : 'text-red-600'}`}>
                      {formatCurrency(summary.totalBalance)}
                  </p>
                </div>
            </div>
        </div>

        <div className="mt-6">
            <div className={`p-4 rounded-lg text-center ${isNetPositive ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}`}>
                <p className="text-sm uppercase tracking-wider">Net Balance (After Savings)</p>
                <p className="text-3xl font-bold">
                    {formatCurrency(netBalance)}
                </p>
            </div>
        </div>
    </Card>
  );
};