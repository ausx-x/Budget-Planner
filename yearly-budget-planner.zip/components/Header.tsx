
import React from 'react';
import { Currency } from '../types';

interface HeaderProps {
  selectedYear: number;
  setSelectedYear: (year: number) => void;
  currency: Currency;
  setCurrency: (currency: Currency) => void;
}

export const Header: React.FC<HeaderProps> = ({ selectedYear, setSelectedYear, currency, setCurrency }) => {
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 10 }, (_, i) => currentYear - 5 + i);

  return (
    <header className="bg-white shadow-sm mb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-slate-800">
          Budget Planner
        </h1>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1 p-1 bg-slate-100 rounded-lg">
              <button 
                onClick={() => setCurrency(Currency.INR)} 
                className={`px-3 py-1 text-sm font-medium rounded-md transition-colors ${currency === Currency.INR ? 'bg-white text-indigo-700 shadow' : 'text-slate-600 hover:bg-slate-200'}`}
              >
                INR (₹)
              </button>
              <button 
                onClick={() => setCurrency(Currency.USD)} 
                className={`px-3 py-1 text-sm font-medium rounded-md transition-colors ${currency === Currency.USD ? 'bg-white text-indigo-700 shadow' : 'text-slate-600 hover:bg-slate-200'}`}
              >
                USD ($)
              </button>
          </div>
          <div className="flex items-center space-x-2">
            <label htmlFor="year-select" className="text-sm font-medium text-slate-600">Year:</label>
            <select
              id="year-select"
              value={selectedYear}
              onChange={(e) => setSelectedYear(parseInt(e.target.value))}
              className="block w-full pl-3 pr-10 py-2 text-base bg-white text-slate-900 border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
            >
              {years.map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </header>
  );
};