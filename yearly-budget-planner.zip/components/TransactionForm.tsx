import React, { useState } from 'react';
import { TransactionType, ExpenseCategory, Transaction } from '../types';
import { EXPENSE_CATEGORIES } from '../constants';
import { Card, CardHeader } from './Card';

interface TransactionFormProps {
  addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  addToast: (message: string) => void;
}

export const TransactionForm: React.FC<TransactionFormProps> = ({ addTransaction, addToast }) => {
  const [type, setType] = useState<TransactionType>(TransactionType.EXPENSE);
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [category, setCategory] = useState<ExpenseCategory>(ExpenseCategory.FOOD);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description || !amount || !date) return;
    
    const newTransaction: Omit<Transaction, 'id'> = {
      type,
      description,
      amount: parseFloat(amount),
      date: new Date(date).toISOString(),
      ...(type === TransactionType.EXPENSE && { category }),
    };
    
    addTransaction(newTransaction);
    addToast('Transaction added successfully!');
    
    // Reset form
    setDescription('');
    setAmount('');
  };

  return (
    <Card>
      <CardHeader>Add New Transaction</CardHeader>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <div className="flex rounded-md shadow-sm">
            <button
              type="button"
              onClick={() => setType(TransactionType.EXPENSE)}
              className={`px-4 py-2 text-sm font-medium border-y border-l rounded-l-md w-1/2 transition-colors ${type === TransactionType.EXPENSE ? 'bg-indigo-600 text-white' : 'bg-white text-slate-700 hover:bg-slate-50'}`}
            >
              Expense
            </button>
            <button
              type="button"
              onClick={() => setType(TransactionType.INCOME)}
              className={`px-4 py-2 text-sm font-medium border rounded-r-md w-1/2 transition-colors ${type === TransactionType.INCOME ? 'bg-indigo-600 text-white' : 'bg-white text-slate-700 hover:bg-slate-50'}`}
            >
              Income
            </button>
          </div>
        </div>
        
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-slate-700">Description</label>
          <input
            type="text"
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="mt-1 block w-full rounded-md bg-white text-slate-900 border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            required
          />
        </div>

        <div>
          <label htmlFor="amount" className="block text-sm font-medium text-slate-700">Amount</label>
          <input
            type="number"
            id="amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="mt-1 block w-full rounded-md bg-white text-slate-900 border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            placeholder="0"
            required
            min="0.01"
            step="0.01"
          />
        </div>
        
        <div>
          <label htmlFor="date" className="block text-sm font-medium text-slate-700">Date</label>
          <input
            type="date"
            id="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="mt-1 block w-full rounded-md bg-white text-slate-900 border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            required
          />
        </div>
        
        {type === TransactionType.EXPENSE && (
          <div>
            <label htmlFor="category" className="block text-sm font-medium text-slate-700">Category</label>
            <select
              id="category"
              value={category}
              onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
              className="mt-1 block w-full rounded-md bg-white text-slate-900 border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            >
              {EXPENSE_CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
            </select>
          </div>
        )}
        
        <button type="submit" className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
          Add Transaction
        </button>
      </form>
    </Card>
  );
};