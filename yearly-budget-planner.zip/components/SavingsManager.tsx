import React, { useState } from 'react';
import { SavingsGoal } from '../types';
import { Card, CardHeader } from './Card';
import { TrashIcon, PiggyBankIcon, EditIcon } from './icons';

interface SavingsManagerProps {
  savingsGoals: SavingsGoal[];
  addSavingsGoal: (goal: Omit<SavingsGoal, 'id'>) => void;
  updateSavingsGoal: (goal: SavingsGoal) => void;
  deleteSavingsGoal: (id: string) => void;
  formatCurrency: (amount: number) => string;
  addToast: (message: string) => void;
}

export const SavingsManager: React.FC<SavingsManagerProps> = ({
  savingsGoals,
  addSavingsGoal,
  updateSavingsGoal,
  deleteSavingsGoal,
  formatCurrency,
  addToast,
}) => {
  const [destination, setDestination] = useState('');
  const [amount, setAmount] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);

  const resetForm = () => {
    setDestination('');
    setAmount('');
    setEditingId(null);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!destination || !amount) return;
    
    if (editingId) {
        updateSavingsGoal({ id: editingId, destination, amount: parseFloat(amount) });
        addToast('Savings goal updated!');
    } else {
        addSavingsGoal({ destination, amount: parseFloat(amount) });
        addToast('Savings goal added!');
    }
    
    resetForm();
  };

  const handleEdit = (goal: SavingsGoal) => {
    setEditingId(goal.id);
    setDestination(goal.destination);
    setAmount(goal.amount.toString());
  };

  const handleDelete = (id: string) => {
    deleteSavingsGoal(id);
    addToast('Savings goal deleted!');
  };

  const totalSavings = savingsGoals.reduce((sum, goal) => sum + goal.amount, 0);

  return (
    <Card>
      <CardHeader>Monthly Savings Goals</CardHeader>
       <div className="mb-4 space-y-2 max-h-48 overflow-y-auto pr-2">
        {savingsGoals.map(goal => (
          <div key={goal.id} className="flex justify-between items-center bg-slate-100 p-2 rounded-md">
            <p className="font-medium text-slate-800">{goal.destination}</p>
            <div className="flex items-center space-x-2">
                <span className="font-semibold text-indigo-600">{formatCurrency(goal.amount)}</span>
                 <button onClick={() => handleEdit(goal)} className="text-slate-500 hover:text-indigo-600">
                    <EditIcon className="h-4 w-4" />
                </button>
                <button onClick={() => handleDelete(goal.id)} className="text-slate-500 hover:text-red-700">
                    <TrashIcon className="h-4 w-4" />
                </button>
            </div>
          </div>
        ))}
      </div>
       <div className="text-right font-bold text-slate-700 p-2 border-t">
        Total: {formatCurrency(totalSavings)} / month
      </div>

      <form onSubmit={handleSubmit} className="space-y-3 pt-4 border-t">
        <h4 className="text-md font-medium text-slate-600">{editingId ? 'Edit' : 'Add New'} Savings Goal</h4>
        <input
          type="text"
          value={destination}
          onChange={e => setDestination(e.target.value)}
          placeholder="Destination (e.g., SIP, FD)"
          className="block w-full text-sm rounded-md bg-white text-slate-900 border-gray-300 shadow-sm"
          required
        />
        <input
          type="number"
          value={amount}
          onChange={e => setAmount(e.target.value)}
          placeholder="Amount"
          className="block w-full text-sm rounded-md bg-white text-slate-900 border-gray-300 shadow-sm"
          required
          min="0.01"
          step="0.01"
        />
        <div className="flex space-x-2">
            <button type="submit" className="w-full flex items-center justify-center bg-indigo-600 text-white py-2 px-4 text-sm rounded-md hover:bg-indigo-700">
                <PiggyBankIcon className="h-5 w-5 mr-2" /> {editingId ? 'Update Goal' : 'Add Goal'}
            </button>
            {editingId && (
                <button type="button" onClick={resetForm} className="w-full bg-slate-200 text-slate-700 py-2 px-4 text-sm rounded-md hover:bg-slate-300">
                    Cancel
                </button>
            )}
        </div>
      </form>
    </Card>
  );
};