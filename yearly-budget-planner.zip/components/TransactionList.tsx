import React, { useState, useEffect } from 'react';
import { Transaction, TransactionType, ExpenseCategory } from '../types';
import { EXPENSE_CATEGORIES } from '../constants';
import { Card } from './Card';
import { TrashIcon, ExportIcon, EditIcon, XIcon } from './icons';

interface TransactionListProps {
  income: Transaction[];
  expenses: Transaction[];
  updateTransaction: (transaction: Transaction) => void;
  deleteTransaction: (id: string) => void;
  formatCurrency: (amount: number) => string;
  addToast: (message: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  categoryFilter: string;
  setCategoryFilter: (category: string) => void;
  dateRange: { start: string; end: string; };
  setDateRange: (range: { start: string; end: string; }) => void;
}

const EditTransactionModal: React.FC<{
    transaction: Transaction | null;
    onClose: () => void;
    onSave: (transaction: Transaction) => void;
}> = ({ transaction, onClose, onSave }) => {
    const [description, setDescription] = useState('');
    const [amount, setAmount] = useState('');
    const [date, setDate] = useState('');
    const [category, setCategory] = useState<ExpenseCategory>(ExpenseCategory.FOOD);

    useEffect(() => {
        if (transaction) {
            setDescription(transaction.description);
            setAmount(transaction.amount.toString());
            setDate(new Date(transaction.date).toISOString().split('T')[0]);
            if (transaction.type === TransactionType.EXPENSE && transaction.category) {
                setCategory(transaction.category);
            }
        }
    }, [transaction]);
    
    if (!transaction) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            ...transaction,
            description,
            amount: parseFloat(amount),
            date: new Date(date).toISOString(),
            category: transaction.type === TransactionType.EXPENSE ? category : undefined,
        });
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold">Edit Transaction</h3>
                    <button onClick={onClose}><XIcon className="h-6 w-6 text-slate-500" /></button>
                </div>
                <form onSubmit={handleSubmit} className="space-y-4">
                     <div>
                        <label htmlFor="edit-description" className="block text-sm font-medium text-slate-700">Description</label>
                        <input type="text" id="edit-description" value={description} onChange={(e) => setDescription(e.target.value)} className="mt-1 block w-full rounded-md bg-white text-slate-900 border-gray-300 shadow-sm" required />
                    </div>
                    <div>
                        <label htmlFor="edit-amount" className="block text-sm font-medium text-slate-700">Amount</label>
                        <input type="number" id="edit-amount" value={amount} onChange={(e) => setAmount(e.target.value)} className="mt-1 block w-full rounded-md bg-white text-slate-900 border-gray-300 shadow-sm" required min="0.01" step="0.01" />
                    </div>
                    <div>
                        <label htmlFor="edit-date" className="block text-sm font-medium text-slate-700">Date</label>
                        <input type="date" id="edit-date" value={date} onChange={(e) => setDate(e.target.value)} className="mt-1 block w-full rounded-md bg-white text-slate-900 border-gray-300 shadow-sm" required />
                    </div>
                    {transaction.type === TransactionType.EXPENSE && (
                        <div>
                            <label htmlFor="edit-category" className="block text-sm font-medium text-slate-700">Category</label>
                            <select id="edit-category" value={category} onChange={(e) => setCategory(e.target.value as ExpenseCategory)} className="mt-1 block w-full rounded-md bg-white text-slate-900 border-gray-300 shadow-sm">
                                {EXPENSE_CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                            </select>
                        </div>
                    )}
                    <div className="flex justify-end space-x-2 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-sm bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300">Cancel</button>
                        <button type="submit" className="px-4 py-2 text-sm bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

const List: React.FC<{ transactions: Transaction[], onEdit: (t: Transaction) => void, onDelete: (id: string) => void, type: TransactionType, formatCurrency: (amount: number) => string }> = ({ transactions, onEdit, onDelete, type, formatCurrency }) => {
  if (transactions.length === 0) {
    return <p className="text-center text-slate-500 py-8">No matching {type === TransactionType.INCOME ? 'income' : 'expenses'} found.</p>;
  }
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm text-left text-slate-500">
        <thead className="text-xs text-slate-700 uppercase bg-slate-50">
          <tr>
            <th scope="col" className="px-4 py-3">Date</th>
            <th scope="col" className="px-4 py-3">Description</th>
            {type === TransactionType.EXPENSE && <th scope="col" className="px-4 py-3">Category</th>}
            <th scope="col" className="px-4 py-3 text-right">Amount</th>
            <th scope="col" className="px-4 py-3"></th>
          </tr>
        </thead>
        <tbody>
          {transactions.map(t => (
            <tr key={t.id} className="bg-white border-b hover:bg-slate-50">
              <td className="px-4 py-3">{formatDate(t.date)}</td>
              <th scope="row" className="px-4 py-3 font-medium text-slate-900 whitespace-nowrap">{t.description}</th>
              {type === TransactionType.EXPENSE && <td className="px-4 py-3">{t.category}</td>}
              <td className={`px-4 py-3 text-right font-semibold ${type === TransactionType.INCOME ? 'text-green-600' : 'text-red-600'}`}>{formatCurrency(t.amount)}</td>
              <td className="px-4 py-3 text-right">
                <div className="flex items-center justify-end space-x-2">
                    <button onClick={() => onEdit(t)} className="text-slate-400 hover:text-indigo-600"><EditIcon className="h-4 w-4" /></button>
                    <button onClick={() => onDelete(t.id)} className="text-slate-400 hover:text-red-600"><TrashIcon className="h-4 w-4" /></button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};


export const TransactionList: React.FC<TransactionListProps> = ({ 
    income, 
    expenses,
    updateTransaction,
    deleteTransaction, 
    formatCurrency,
    addToast,
    searchQuery,
    setSearchQuery,
    categoryFilter,
    setCategoryFilter,
    dateRange,
    setDateRange
}) => {
  const [activeTab, setActiveTab] = useState<'income' | 'expenses'>('expenses');
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);

  const handleResetFilters = () => {
    setSearchQuery('');
    setCategoryFilter('all');
    setDateRange({ start: '', end: '' });
  };

  const handleSaveTransaction = (transaction: Transaction) => {
    updateTransaction(transaction);
    addToast('Transaction updated successfully!');
    setEditingTransaction(null);
  };

  const handleDeleteTransaction = (id: string) => {
    deleteTransaction(id);
    addToast('Transaction deleted!');
  };
  
  const handleExport = () => {
    const allTransactions = [
      ...income.map(t => ({...t, type: 'Income'})),
      ...expenses.map(t => ({...t, type: 'Expense'}))
    ].sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Date,Description,Category,Type,Amount\n";

    allTransactions.forEach(t => {
      const row = [
        new Date(t.date).toLocaleDateString('en-CA'), // YYYY-MM-DD
        `"${t.description.replace(/"/g, '""')}"`,
        t.category || '',
        t.type,
        t.amount
      ].join(',');
      csvContent += row + "\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "transactions.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Card>
      <div className="flex flex-col md:flex-row justify-between md:items-center border-b border-slate-200 mb-4 pb-2">
        <h3 className="text-lg font-semibold text-slate-700 mb-3 md:mb-0">Transactions</h3>
        <div className="text-sm font-medium text-center text-slate-500">
            <ul className="flex flex-wrap -mb-px">
                <li className="mr-2">
                    <button onClick={() => setActiveTab('expenses')} className={`inline-block p-4 rounded-t-lg border-b-2 ${activeTab === 'expenses' ? 'text-indigo-600 border-indigo-600' : 'border-transparent hover:text-slate-600 hover:border-slate-300'}`}>
                        Expenses
                    </button>
                </li>
                <li className="mr-2">
                    <button onClick={() => setActiveTab('income')} className={`inline-block p-4 rounded-t-lg border-b-2 ${activeTab === 'income' ? 'text-indigo-600 border-indigo-600' : 'border-transparent hover:text-slate-600 hover:border-slate-300'}`}>
                        Income
                    </button>
                </li>
            </ul>
        </div>
      </div>
      
      {/* Filters */}
      <div className="p-4 bg-slate-50 rounded-lg mb-4 space-y-4 md:space-y-0 md:flex md:items-end md:space-x-4">
        <div className="flex-grow">
          <label htmlFor="search-query" className="block text-xs font-medium text-slate-600">Search</label>
          <input
            id="search-query"
            type="text"
            placeholder="Filter by description..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="mt-1 block w-full text-sm rounded-md bg-white text-slate-900 border-gray-300 shadow-sm"
          />
        </div>
        
        {activeTab === 'expenses' && (
          <div className="flex-grow">
            <label htmlFor="category-filter" className="block text-xs font-medium text-slate-600">Category</label>
            <select
              id="category-filter"
              value={categoryFilter}
              onChange={e => setCategoryFilter(e.target.value)}
              className="mt-1 block w-full text-sm rounded-md bg-white text-slate-900 border-gray-300 shadow-sm"
            >
              <option value="all">All Categories</option>
              {EXPENSE_CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
            </select>
          </div>
        )}

        <div className="flex-grow">
            <label htmlFor="start-date" className="block text-xs font-medium text-slate-600">Start Date</label>
            <input type="date" id="start-date" value={dateRange.start} onChange={e => setDateRange({...dateRange, start: e.target.value})} className="mt-1 block w-full text-sm rounded-md bg-white text-slate-900 border-gray-300 shadow-sm"/>
        </div>
        <div className="flex-grow">
            <label htmlFor="end-date" className="block text-xs font-medium text-slate-600">End Date</label>
            <input type="date" id="end-date" value={dateRange.end} onChange={e => setDateRange({...dateRange, end: e.target.value})} className="mt-1 block w-full text-sm rounded-md bg-white text-slate-900 border-gray-300 shadow-sm"/>
        </div>

        <div className="flex items-center space-x-2">
            <button onClick={handleResetFilters} className="px-4 py-2 text-sm bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300">Reset</button>
            <button onClick={handleExport} className="px-4 py-2 text-sm bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center"><ExportIcon className="h-4 w-4 mr-2"/> Export to CSV</button>
        </div>
      </div>


      {activeTab === 'income' && <List transactions={income} onEdit={setEditingTransaction} onDelete={handleDeleteTransaction} type={TransactionType.INCOME} formatCurrency={formatCurrency} />}
      {activeTab === 'expenses' && <List transactions={expenses} onEdit={setEditingTransaction} onDelete={handleDeleteTransaction} type={TransactionType.EXPENSE} formatCurrency={formatCurrency} />}

      <EditTransactionModal transaction={editingTransaction} onClose={() => setEditingTransaction(null)} onSave={handleSaveTransaction} />
    </Card>
  );
};