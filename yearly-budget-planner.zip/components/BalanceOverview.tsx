
import React, { useState, useMemo } from 'react';
import { MonthlySummary } from '../types';
import { Card } from './Card';

interface BalanceOverviewProps {
  monthlySummaries: MonthlySummary[];
  formatCurrency: (amount: number) => string;
}

const FILTERS: { [key: string]: [number, number] } = {
  'All Year': [0, 11],
  'Quarter 1': [0, 2],
  'Quarter 2': [3, 5],
  'Quarter 3': [6, 8],
  'Quarter 4': [9, 11],
  'First Half': [0, 5],
  'Second Half': [6, 11]
};

export const BalanceOverview: React.FC<BalanceOverviewProps> = ({ monthlySummaries, formatCurrency }) => {
  const [activeFilter, setActiveFilter] = useState('All Year');

  const filteredSummaries = useMemo(() => {
    const [start, end] = FILTERS[activeFilter];
    return monthlySummaries.slice(start, end + 1);
  }, [activeFilter, monthlySummaries]);

  return (
    <Card>
      <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-4 pb-2 border-b border-slate-200">
         <h3 className="text-lg font-semibold text-slate-700 mb-2 sm:mb-0">Monthly Overview</h3>
         <div>
            <select
                value={activeFilter}
                onChange={(e) => setActiveFilter(e.target.value)}
                className="block w-full sm:w-auto pl-3 pr-10 py-2 text-base bg-white text-slate-900 border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
            >
                {Object.keys(FILTERS).map(filterKey => (
                    <option key={filterKey} value={filterKey}>{filterKey}</option>
                ))}
            </select>
         </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredSummaries.map((summary) => (
          <div key={summary.monthIndex} className={`p-4 rounded-lg shadow-sm border-l-4 ${summary.balance >= 0 ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'}`}>
            <p className="font-bold text-slate-700">{summary.month}</p>
            <div className="mt-2 space-y-1 text-sm">
                <div className="flex items-center justify-between text-green-700">
                    <span className="font-medium">Income</span>
                    <span>{formatCurrency(summary.income)}</span>
                </div>
                <div className="flex items-center justify-between text-red-700">
                    <span className="font-medium">Expenses</span>
                    <span>{formatCurrency(summary.expenses)}</span>
                </div>
                <div className="flex items-center justify-between text-slate-800 pt-1 border-t mt-1">
                    <span className="font-bold">Balance</span>
                    <span className="font-bold">{formatCurrency(summary.balance)}</span>
                </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
};
