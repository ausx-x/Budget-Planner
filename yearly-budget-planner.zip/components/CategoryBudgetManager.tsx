import React, { useState, useMemo, useEffect } from 'react';
import { CategoryBudget, ExpenseCategory } from '../types';
import { EXPENSE_CATEGORIES } from '../constants';
import { Card, CardHeader } from './Card';
import { TrashIcon, PlusCircleIcon } from './icons';

interface CategoryBudgetManagerProps {
  categoryBudgets: CategoryBudget[];
  setCategoryBudget: (budget: CategoryBudget) => void;
  deleteCategoryBudget: (category: ExpenseCategory) => void;
  formatCurrency: (amount: number) => string;
  addToast: (message: string) => void;
}

export const CategoryBudgetManager: React.FC<CategoryBudgetManagerProps> = ({
  categoryBudgets,
  setCategoryBudget,
  deleteCategoryBudget,
  formatCurrency,
  addToast,
}) => {
  const [amount, setAmount] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ExpenseCategory>(EXPENSE_CATEGORIES[0]);
  
  const unbudgetedCategories = useMemo(() => {
    const budgeted = categoryBudgets.map(b => b.category);
    return EXPENSE_CATEGORIES.filter(c => !budgeted.includes(c));
  }, [categoryBudgets]);

  // FIX: The `useEffect` hook was used without being imported. It has been added to the import statement from 'react'.
  useEffect(() => {
      if(unbudgetedCategories.length > 0) {
        setSelectedCategory(unbudgetedCategories[0]);
      }
  }, [unbudgetedCategories]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !selectedCategory) return;
    
    setCategoryBudget({
      category: selectedCategory,
      amount: parseFloat(amount)
    });
    addToast(`Budget for ${selectedCategory} set!`);
    
    setAmount('');
  };

  const handleDelete = (category: ExpenseCategory) => {
    deleteCategoryBudget(category);
    addToast(`Budget for ${category} removed!`);
  };

  return (
    <Card>
      <CardHeader>Category Budgets</CardHeader>
      <div className="mb-4 space-y-2 max-h-48 overflow-y-auto pr-2">
        {categoryBudgets.map(budget => (
          <div key={budget.category} className="flex justify-between items-center bg-slate-100 p-2 rounded-md">
            <p className="font-medium text-slate-800">{budget.category}</p>
            <div className="flex items-center space-x-2">
                <span className="font-semibold text-slate-800">{formatCurrency(budget.amount)}</span>
                <button onClick={() => handleDelete(budget.category)} className="text-red-500 hover:text-red-700">
                    <TrashIcon className="h-4 w-4" />
                </button>
            </div>
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="space-y-3 pt-4 border-t">
        <h4 className="text-md font-medium text-slate-600">Set New Budget</h4>
        <select
          value={selectedCategory}
          onChange={e => setSelectedCategory(e.target.value as ExpenseCategory)}
          className="block w-full text-sm rounded-md bg-white text-slate-900 border-gray-300 shadow-sm"
          disabled={unbudgetedCategories.length === 0}
        >
          {unbudgetedCategories.length > 0 ? (
            unbudgetedCategories.map(cat => <option key={cat} value={cat}>{cat}</option>)
          ) : (
            <option>All budgets set!</option>
          )}
        </select>
         <input
          type="number"
          value={amount}
          onChange={e => setAmount(e.target.value)}
          placeholder="Budget Amount"
          className="block w-full text-sm rounded-md bg-white text-slate-900 border-gray-300 shadow-sm"
          required
          min="0.01"
          step="0.01"
          disabled={unbudgetedCategories.length === 0}
        />
        <button type="submit" className="w-full flex items-center justify-center bg-slate-600 text-white py-2 px-4 text-sm rounded-md hover:bg-slate-700 disabled:bg-slate-400" disabled={unbudgetedCategories.length === 0}>
            <PlusCircleIcon className="h-5 w-5 mr-2" /> Set Budget
        </button>
      </form>
    </Card>
  );
};