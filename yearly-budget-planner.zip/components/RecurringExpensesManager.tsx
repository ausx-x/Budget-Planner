import React, { useState, useEffect } from 'react';
import { RecurringExpense, ExpenseCategory } from '../types';
import { EXPENSE_CATEGORIES } from '../constants';
import { Card, CardHeader } from './Card';
import { TrashIcon, PlusCircleIcon, EditIcon, XIcon } from './icons';

interface RecurringExpensesManagerProps {
  recurringExpenses: RecurringExpense[];
  addRecurringExpense: (expense: Omit<RecurringExpense, 'id'>) => void;
  updateRecurringExpense: (expense: RecurringExpense) => void;
  deleteRecurringExpense: (id: string) => void;
  formatCurrency: (amount: number) => string;
  addToast: (message: string) => void;
}

const EditRecurringExpenseModal: React.FC<{
    expense: RecurringExpense | null;
    onClose: () => void;
    onSave: (expense: RecurringExpense) => void;
}> = ({ expense, onClose, onSave }) => {
    const [description, setDescription] = useState('');
    const [amount, setAmount] = useState('');
    const [category, setCategory] = useState<ExpenseCategory>(ExpenseCategory.FOOD);

    useEffect(() => {
        if (expense) {
            setDescription(expense.description);
            setAmount(expense.amount.toString());
            setCategory(expense.category);
        }
    }, [expense]);
    
    if (!expense) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            ...expense,
            description,
            amount: parseFloat(amount),
            category,
        });
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold">Edit Fixed Expense</h3>
                    <button onClick={onClose}><XIcon className="h-6 w-6 text-slate-500" /></button>
                </div>
                <form onSubmit={handleSubmit} className="space-y-4">
                     <div>
                        <label htmlFor="edit-rec-description" className="block text-sm font-medium text-slate-700">Description</label>
                        <input type="text" id="edit-rec-description" value={description} onChange={(e) => setDescription(e.target.value)} className="mt-1 block w-full rounded-md bg-white text-slate-900 border-gray-300 shadow-sm" required />
                    </div>
                    <div>
                        <label htmlFor="edit-rec-amount" className="block text-sm font-medium text-slate-700">Amount</label>
                        <input type="number" id="edit-rec-amount" value={amount} onChange={(e) => setAmount(e.target.value)} className="mt-1 block w-full rounded-md bg-white text-slate-900 border-gray-300 shadow-sm" required min="0.01" step="0.01" />
                    </div>
                    <div>
                        <label htmlFor="edit-rec-category" className="block text-sm font-medium text-slate-700">Category</label>
                        <select id="edit-rec-category" value={category} onChange={(e) => setCategory(e.target.value as ExpenseCategory)} className="mt-1 block w-full rounded-md bg-white text-slate-900 border-gray-300 shadow-sm">
                            {EXPENSE_CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                        </select>
                    </div>
                    <div className="flex justify-end space-x-2 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-sm bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300">Cancel</button>
                        <button type="submit" className="px-4 py-2 text-sm bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    );
};


export const RecurringExpensesManager: React.FC<RecurringExpensesManagerProps> = ({
  recurringExpenses,
  addRecurringExpense,
  updateRecurringExpense,
  deleteRecurringExpense,
  formatCurrency,
  addToast,
}) => {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>(ExpenseCategory.HOUSING);
  const [editingExpense, setEditingExpense] = useState<RecurringExpense | null>(null);

  const resetForm = () => {
    setDescription('');
    setAmount('');
    setCategory(ExpenseCategory.HOUSING);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description || !amount) return;
    
    addRecurringExpense({ description, amount: parseFloat(amount), category });
    addToast('Fixed expense added!');
    
    resetForm();
  };

  const handleSave = (expense: RecurringExpense) => {
    updateRecurringExpense(expense);
    addToast('Fixed expense updated!');
    setEditingExpense(null);
  };

  const handleDelete = (id: string) => {
    deleteRecurringExpense(id);
    addToast('Fixed expense deleted!');
  };

  return (
    <Card>
      <CardHeader>Fixed Monthly Expenses</CardHeader>
      <div className="mb-4 space-y-2 max-h-48 overflow-y-auto pr-2">
        {recurringExpenses.map(expense => (
          <div key={expense.id} className="flex justify-between items-center bg-slate-100 p-2 rounded-md">
            <div>
              <p className="font-medium text-slate-800">{expense.description}</p>
              <p className="text-xs text-slate-500">{expense.category}</p>
            </div>
            <div className="flex items-center space-x-2">
                <span className="font-semibold text-slate-800">{formatCurrency(expense.amount)}</span>
                <button onClick={() => setEditingExpense(expense)} className="text-slate-500 hover:text-indigo-600">
                    <EditIcon className="h-4 w-4" />
                </button>
                <button onClick={() => handleDelete(expense.id)} className="text-slate-500 hover:text-red-700">
                    <TrashIcon className="h-4 w-4" />
                </button>
            </div>
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="space-y-3 pt-4 border-t">
        <h4 className="text-md font-medium text-slate-600">Add New Fixed Expense</h4>
        <input
          type="text"
          value={description}
          onChange={e => setDescription(e.target.value)}
          placeholder="Description (e.g., Rent)"
          className="block w-full text-sm rounded-md bg-white text-slate-900 border-gray-300 shadow-sm"
          required
        />
        <input
          type="number"
          value={amount}
          onChange={e => setAmount(e.target.value)}
          placeholder="Amount"
          className="block w-full text-sm rounded-md bg-white text-slate-900 border-gray-300 shadow-sm"
          required
          min="0.01"
          step="0.01"
        />
        <select
          value={category}
          onChange={e => setCategory(e.target.value as ExpenseCategory)}
          className="block w-full text-sm rounded-md bg-white text-slate-900 border-gray-300 shadow-sm"
        >
          {EXPENSE_CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
        </select>
        <div className="flex space-x-2">
            <button type="submit" className="w-full flex items-center justify-center bg-slate-600 text-white py-2 px-4 text-sm rounded-md hover:bg-slate-700">
                <PlusCircleIcon className="h-5 w-5 mr-2" /> Add Expense
            </button>
        </div>
      </form>
      <EditRecurringExpenseModal
        expense={editingExpense}
        onClose={() => setEditingExpense(null)}
        onSave={handleSave}
      />
    </Card>
  );
};